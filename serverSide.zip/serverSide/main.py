from flask import Flask, render_template, request, flash, redirect, url_for
import secrets
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import relationship

app = Flask(__name__, template_folder = 'templates')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///teste.db'

secret_key = secrets.token_hex(32)

app.config['SECRET_KEY'] = secret_key

app.app_context().push()
db = SQLAlchemy(app)

class Estudante(db.Model):
    id = db.Column('studentId',db.Integer, primary_key=True)
    nome = db.Column(db.String(200))
    cidade = db.Column(db.String(100))
    email = db.Column(db.String(100))
    pin = db.Column(db.String(20))

    def __init__(self,nome_aux,cidade_aux,email_aux,pin_aux):
        self.nome = nome_aux
        self.cidade = cidade_aux
        self.email = email_aux
        self.pin = pin_aux

class Telefone(db.Model):
    id = db.Column('phoneId', db.Integer, primary_key = True)
    descricao = db.Column(db.String(200))
    numero = db.Column(db.String(15))
    estudante_id = db.Column(db.Integer, db.ForeignKey("estudante.studentId"))
    estudante = relationship("Estudante", backref = "telefone")

    def __init__(self, descricao, numero, estudante):
        self.descricao = descricao
        self.numero = numero
        self.estudante = estudante


@app.route("/")
def show_all():
    return render_template('show_all.html', estudantes = Estudante.query.all())

@app.route("/new", methods=['GET', 'POST'])
def new():
    if request.method == 'POST':
        if not request.form['nome'] or not request.form['cidade'] or not request.form['email'] or not request.form['pin']:
            flash("Preencha todos os campos", "Erro")
        else:
            estudante = Estudante(request.form['nome'], request.form['cidade'], request.form['email'], request.form['pin'])
            db.session.add(estudante)
            db.session.commit()
            flash("Estudante criado com sucesso!")
            return redirect(url_for('show_all'))

    return render_template('new.html')

@app.route("/update/<int:id>", methods = ['GET','POST'])
def update(id):
    estudante = Estudante.query.get(id)
    if request.method == 'POST':
        if not request.form['nome'] or not request.form['cidade'] or not request.form['email'] or not request.form['pin']:
            flash("Preencha todos os campos", "Erro")
        else:
            estudante.nome = request.form['nome']
            estudante.cidade = request.form['cidade']
            estudante.email = request.form['email']
            estudante.pin = request.form['pin']
            db.session.add(estudante)
            db.session.commit()
            flash("Estudante "+estudante.nome+ " atualizado com sucesso")
            return redirect(url_for('show_all'))

    return render_template('update.html', estudante=estudante)

@app.route("/delete/<int:id>")
def delete(id):
    estudante = Estudante.query.get(id)
    db.session.delete(estudante)
    db.session.commit()
    flash("Estudante " +estudante.nome + " deletado")
    return redirect(url_for('show_all'))

@app.route("/add_phone/<int:id>")
def add_phone(id):
    studant = Estudante.query.get(id)
    telephone = Telefone("celular", "+47945728374", studant)

    db.session.add(telephone)
    db.session.commit()

    flash(studant.nome + " adicionou o numero "+telephone.numero)
    return redirect(url_for('show_all'))


if __name__ == '__main__':
    db.create_all()
    app.run(port=3000, debug=True)
